﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class IndicatorAbility : MonoBehaviour {
    
    [SerializeField] private float randomOffset = 5;
    [SerializeField] private float maxDistance;

    private Image img1;
    private float indicatorAngle;
    private IEnumerator pingCoroutine;
    private IEnumerator pingStartCoroutine;

    public GameObject testObj; //remove

    
	void Start ()
    {
        img1 = transform.GetChild(0).GetComponent<Image>();
	}
	


	void Update ()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            SetNewPoint(testObj.transform, Vector3.zero);
        }
        
	}


    
    public void SetNewPoint(Transform player, Vector3 targetPoint)
    {
        //Disable previous coroutine
        if (pingStartCoroutine != null)
        {
            StopCoroutine(pingStartCoroutine);
        }

        //Randomize location
        targetPoint.x += Random.Range(-randomOffset, randomOffset);
        targetPoint.y += Random.Range(-randomOffset, randomOffset);
        targetPoint.z += Random.Range(-randomOffset, randomOffset);

        
        StartCoroutine(StartPing(player, targetPoint));
    }


    IEnumerator StartPing(Transform player, Vector3 targetPoint)
    {
        float t = 0;
        while (t < Vector3.Distance(player.position, targetPoint))
        {
            t += Time.deltaTime * 20;
            yield return null;
        }
        if (pingCoroutine != null)
        {
            StopCoroutine(pingCoroutine);
        }
        pingCoroutine = SetNewPing(player, targetPoint);
        StartCoroutine(pingCoroutine);
    }

    IEnumerator SetNewPing(Transform player, Vector3 targetPoint)
    {
        float duration = 0.5f * Vector3.Distance(player.position, targetPoint);
        float timer = 0;
        float  tempT = 5;
        img1.color = Color.red;
        while (timer < duration)
        {
            float distance = Vector3.Distance(player.position, targetPoint);
            duration = 0.2f * distance; //set the duration to distance
            //calculate the angles into 360 degrees
            timer += Time.deltaTime;
            if (Vector3.SignedAngle(player.position - targetPoint, player.forward, Vector3.up) < 0)
            {
                indicatorAngle = Vector3.Angle( player.forward, player.position - targetPoint);
            }
            else
            {
                indicatorAngle = 360 - Vector3.Angle(player.forward, player.position - targetPoint);
            }

            //Update UI
            distance /= maxDistance;
            //img1.color = Color.Lerp(img1.color, Color.clear, (tempT-duration) /duration * Time.deltaTime);
            img1.color = Color.Lerp(img1.color, Color.clear, 0.2f * (timer+tempT-duration) * Time.deltaTime);
            img1.transform.rotation = Quaternion.identity;
            img1.transform.Rotate(-Vector3.forward, indicatorAngle + 90 + distance / 2 * 360);
            img1.fillAmount = 0.5f - distance;
            Debug.Log(Vector3.Angle(player.forward, player.position - targetPoint));

            yield return null;
        }
        img1.color = Color.clear;

    }

}