﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HookAbility : MonoBehaviour {


    private GameObject hookObj;
    [SerializeField] private GameObject hookPrefab;
    [SerializeField] private float hookDistance;
    [SerializeField] private float hookSpeed;
    [SerializeField] private float slowDown;
    private bool hookShot = false;

    Vector3 move; //testi

    void Start ()
    {

	}
	


	void Update () //testing (Delete)
    {
		if (Input.GetKeyDown(KeyCode.E))
        {
            ShootHook();
        }
        if (Input.GetKey(KeyCode.W))
        {
            transform.Translate(Vector3.forward * 20 * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.Translate(-Vector3.forward * 20 * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector3.right * 20 * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(-Vector3.right * 20 * Time.deltaTime);
        }
        move.y = Input.GetAxis("Mouse X");
        transform.Rotate(move * 100 * Time.deltaTime);
    }

    void ShootHook()
    {
        if (!hookShot)
        {


            hookObj = Instantiate(hookPrefab, transform.position, transform.rotation);
            hookObj.GetComponent<Hook>().SetValues(gameObject, transform.forward, hookSpeed);
            Invoke("ResetHook", hookDistance);
            hookShot = true;
        }
    }

    void ResetHook()
    {
        if (!hookObj.GetComponent<Hook>().hitTarget)
        {
            Destroy(hookObj);
            hookShot = false;
        }
    }

}
