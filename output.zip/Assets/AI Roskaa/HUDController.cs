﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HUDController : MonoBehaviour {

    //Testing
    private float curProgress;
    private float curHealth;

    public int maxHealth = 150; //Set to max health

    //Stat UI
    [SerializeField] private Slider progressSlider;
    [SerializeField] private Text curHealthText;
    [SerializeField] private Text maxHealthText;

    //Cooldown UI
    [SerializeField] private int abilityCount;
    [SerializeField] private List<GameObject> coolDownObjects;



    void Start ()
    {
        
        UpdateHUD();
    }

    
	void Update () //remove this update after testing =)
    {
		
        if (Input.GetKeyDown(KeyCode.T))
        {
            curHealth = Random.Range(0,maxHealth);
            curProgress = Random.Range(0, 100);
            UpdateHUD();
            UpdateCooldowns();
        }
	}


    private void UpdateHUD() //set reference to player here
    {
        curHealthText.text = "" + curHealth;
        maxHealthText.text = "/" + maxHealth;
        progressSlider.value = curProgress * 0.01f;
    }

    private void UpdateCooldowns() //for testing
    {
        StartCoroutine(Cooldown(5, coolDownObjects[0]));
        StartCoroutine(Cooldown(5, coolDownObjects[1]));
        StartCoroutine(Cooldown(5, coolDownObjects[2]));
    }

    IEnumerator Cooldown(float cd, GameObject cdObj) //set cooldown number and fill for UI element
    {
        float temp = 0;
        while (temp < cd)
        {
            temp += Time.deltaTime;
            cdObj.GetComponentInChildren<Text>().text = ((int)(cd - temp)+ 1).ToString();
            cdObj.transform.GetChild(0).GetComponent<Image>().fillAmount = 1 - temp / cd;
            yield return null;
        }
        cdObj.transform.GetChild(0).GetComponent<Image>().fillAmount = 0;
        cdObj.GetComponentInChildren<Text>().text = "";
    }
}
